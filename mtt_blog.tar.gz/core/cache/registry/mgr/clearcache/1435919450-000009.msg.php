<?php
return array (
  'timestamp' => '2015-07-03 13:30:50',
  'level' => 'INFO',
  'msg' => 'Очистка кэша сниппетов/плагинов: Обновлено успешно!',
  'def' => '',
  'file' => '/connectors/index.php',
  'line' => '',
);
