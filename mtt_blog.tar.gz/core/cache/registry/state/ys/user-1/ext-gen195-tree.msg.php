<?php
return '/Файлы/assets/Template';
