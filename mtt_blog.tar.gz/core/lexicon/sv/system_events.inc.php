<?php
/**
 * System Events English lexicon topic
 *
 * @language en
 * @package modx
 * @subpackage lexicon
 */
$_lang['clear'] = 'Rensa';
$_lang['error_log'] = 'Fellogg';
$_lang['error_log_desc'] = 'Här är felloggen för MODX Revolution:';
$_lang['error_log_download'] = 'Ladda ner fellogg ([[+size]])';
$_lang['error_log_too_large'] = 'Felloggen för <em>[[+name]]</em> är för stor för att visas. Du kan ladda ner den med knappen nedan.';
$_lang['system_events'] = 'Systemhändelser';
$_lang['priority'] = 'Prioritet';