<?php
/**
 * Welcome English lexicon topic
 *
 * @language en
 * @package modx
 * @subpackage lexicon
 */
$_lang['modx_news'] = 'Новости MODX ';
$_lang['security_notices'] = 'Уведомления о безопасности';
$_lang['welcome_messages'] = 'Всего сообщений в вашем почтовом ящике<strong>%d</strong>, из них не прочитано <strong>%s</strong>.';
$_lang['welcome_title'] = 'Добро пожаловать в систему управления контентом MODX.';
$_lang['yourinfo_message'] = 'Этот раздел содержит некоторые данные о вас:';
$_lang['yourinfo_previous_login'] = 'Последняя авторизация:';
$_lang['yourinfo_title'] = 'Информация о вас';
$_lang['yourinfo_total_logins'] = 'Всего авторизаций:';
$_lang['yourinfo_username'] = 'Вы авторизованы как:';