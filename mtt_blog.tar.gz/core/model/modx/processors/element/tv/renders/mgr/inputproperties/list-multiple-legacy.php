<?php
/**
 * @package modx
 * @subpackage processors.element.tv.renders.mgr.inputproperties
 */

return $modx->controller->fetchTemplate('element/tv/renders/inputproperties/list-multiple-legacy.tpl');