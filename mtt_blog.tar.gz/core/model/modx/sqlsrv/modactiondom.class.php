<?php
/**
 * @package modx
 * @subpackage sqlsrv
 */
require_once (dirname(dirname(__FILE__)) . '/modactiondom.class.php');
/**
 * @package modx
 * @subpackage sqlsrv
 */
class modActionDom_sqlsrv extends modActionDom {
}