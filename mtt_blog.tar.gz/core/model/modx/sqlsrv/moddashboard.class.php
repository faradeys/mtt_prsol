<?php
/**
 * @package modx
 * @subpackage sqlsrv
 */
require_once (dirname(dirname(__FILE__)) . '/moddashboard.class.php');
/**
 * @package modx
 * @subpackage sqlsrv
 */
class modDashboard_sqlsrv extends modDashboard {
}