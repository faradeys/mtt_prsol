<?php
/**
 * @package modx
 * @subpackage sqlsrv
 */
require_once (dirname(dirname(__FILE__)) . '/modjsonrpcresource.class.php');
/**
 * @package modx
 * @subpackage sqlsrv
 */
class modJSONRPCResource_sqlsrv extends modJSONRPCResource {
}