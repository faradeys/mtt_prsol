<?php
/**
 * @package modx
 * @subpackage sqlsrv
 */
require_once (dirname(dirname(__FILE__)) . '/modactiveuser.class.php');
/**
 * @package modx
 * @subpackage sqlsrv
 */
class modActiveUser_sqlsrv extends modActiveUser {
}