<?php
/**
 * @package modx
 * @subpackage sqlsrv
 */
require_once (dirname(dirname(__FILE__)) . '/modformcustomizationprofileusergroup.class.php');
/**
 * @package modx
 * @subpackage sqlsrv
 */
class modFormCustomizationProfileUserGroup_sqlsrv extends modFormCustomizationProfileUserGroup {
}