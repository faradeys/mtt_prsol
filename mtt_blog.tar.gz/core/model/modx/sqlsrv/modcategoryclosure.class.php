<?php
/**
 * @package modx
 * @subpackage sqlsrv
 */
require_once (dirname(dirname(__FILE__)) . '/modcategoryclosure.class.php');
/**
 * @package modx
 * @subpackage sqlsrv
 */
class modCategoryClosure_sqlsrv extends modCategoryClosure {
}