<?php
/**
 * @package modx
 * @subpackage sqlsrv
 */
require_once (dirname(dirname(__FILE__)) . '/moduser.class.php');
/**
 * @package modx
 * @subpackage sqlsrv
 */
class modUser_sqlsrv extends modUser {
}