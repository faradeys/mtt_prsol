<?php
/**
 * @package modx
 * @subpackage sqlsrv
 */
require_once (dirname(dirname(__FILE__)) . '/modelement.class.php');
/**
 * @package modx
 * @subpackage sqlsrv
 */
class modElement_sqlsrv extends modElement {
}