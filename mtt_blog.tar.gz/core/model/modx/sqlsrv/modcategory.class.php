<?php
/**
 * @package modx
 * @subpackage sqlsrv
 */
require_once (dirname(dirname(__FILE__)) . '/modcategory.class.php');
/**
 * @package modx
 * @subpackage sqlsrv
 */
class modCategory_sqlsrv extends modCategory {
}