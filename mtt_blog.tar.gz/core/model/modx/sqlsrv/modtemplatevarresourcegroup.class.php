<?php
/**
 * @package modx
 * @subpackage sqlsrv
 */
require_once (dirname(dirname(__FILE__)) . '/modtemplatevarresourcegroup.class.php');
/**
 * @package modx
 * @subpackage sqlsrv
 */
class modTemplateVarResourceGroup_sqlsrv extends modTemplateVarResourceGroup {
}