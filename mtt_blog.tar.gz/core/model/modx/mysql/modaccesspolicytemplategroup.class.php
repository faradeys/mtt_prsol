<?php
/**
 * @package modx
 * @subpackage mysql
 */
require_once (dirname(dirname(__FILE__)) . '/modaccesspolicytemplategroup.class.php');
/**
 * @package modx
 * @subpackage mysql
 */
class modAccessPolicyTemplateGroup_mysql extends modAccessPolicyTemplateGroup {
}