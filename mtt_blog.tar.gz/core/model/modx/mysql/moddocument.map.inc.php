<?php
/**
 * @package modx
 * @subpackage mysql
 */
$xpdo_meta_map['modDocument']= array (
  'package' => 'modx',
  'version' => '1.1',
  'extends' => 'modResource',
  'fields' => 
  array (
  ),
  'fieldMeta' => 
  array (
  ),
);
