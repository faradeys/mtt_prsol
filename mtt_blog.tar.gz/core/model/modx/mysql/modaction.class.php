<?php
/**
 * @package modx
 * @subpackage mysql
 */
require_once (strtr(realpath(dirname(dirname(__FILE__))), '\\', '/') . '/modaction.class.php');
/**
 * @package modx
 * @subpackage mysql
 */
class modAction_mysql extends modAction {}