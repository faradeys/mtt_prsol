<?php
/**
 * @package modx
 * @subpackage sources
 */
/**
 * @package modx
 * @subpackage sources
 */
class modMediaSourceContext extends xPDOObject {}