<?php
/**
 * @package modx
 * @subpackage sources.mysql
 */
require_once (dirname(dirname(__FILE__)) . '/modaccessmediasource.class.php');
/**
 * @package modx
 * @subpackage sources.mysql
 */
class modAccessMediaSource_mysql extends modAccessMediaSource {
}