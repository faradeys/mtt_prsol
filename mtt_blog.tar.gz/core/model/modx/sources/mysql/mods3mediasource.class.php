<?php
/**
 * @package modx
 * @subpackage sources.mysql
 */
require_once (dirname(dirname(__FILE__)) . '/mods3mediasource.class.php');
/**
 * @package modx
 * @subpackage sources.mysql
 */
class modS3MediaSource_mysql extends modS3MediaSource {
}