<?php
/**
 * @package modx
 * @subpackage sources.sqlsrv
 */
require_once (dirname(dirname(__FILE__)) . '/modmediasourceelement.class.php');
/**
 * @package modx
 * @subpackage sources.sqlsrv
 */
class modMediaSourceElement_sqlsrv extends modMediaSourceElement {
}