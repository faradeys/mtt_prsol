<?php
/**
 * @package modx
 * @subpackage sources.sqlsrv
 */
require_once (dirname(dirname(__FILE__)) . '/modmediasourcecontext.class.php');
/**
 * @package modx
 * @subpackage sources.sqlsrv
 */
class modMediaSourceContext_sqlsrv extends modMediaSourceContext {
}